package excavacionesarqueologicas;

import java.time.LocalDate;


public abstract class Descubrimiento {
    private String sitioDeDescubrimiento;
    private LocalDate fechaDeDescubrimiento;
    private int estadoDeConservacion;
    private static final int VALOR_CONSER_MAX = 10;
    private static final int VALOR_CONSER_MIN = 1;
    private static int autoincremental = 50000;
    private int id;

    public Descubrimiento(String sitioDeDescubrimiento, LocalDate fechaDeDescubrimiento, int estadoDeConservacion) {
        this.sitioDeDescubrimiento = sitioDeDescubrimiento;
        this.fechaDeDescubrimiento = fechaDeDescubrimiento;
        validarConservacion(estadoDeConservacion);
        this.estadoDeConservacion = estadoDeConservacion;
        this.id = autoincremental;
        autoincremental ++;
    }
    
    private void validarConservacion(int numero){
        if(numero < VALOR_CONSER_MIN || numero > VALOR_CONSER_MAX){
            throw new IllegalArgumentException("El numero ingresado para el estado de conservacion es invalido. Debe ser mayor o igual a 1 y menor o igual a 10");
        }
    }

    public String getSitioDeDescubrimiento() {
        return sitioDeDescubrimiento;
    }

    public LocalDate getFechaDeDescubrimiento() {
        return fechaDeDescubrimiento;
    }

    public int getEstadoDeConservacion() {
        return estadoDeConservacion;
    }

    public int getId() {
        return id;
    }
    
    @Override
    public String toString(){
        return "Sitio de descubrimiento: "+ sitioDeDescubrimiento+ "\nFecha de descubrimiento: "+ fechaDeDescubrimiento + "\nEstado de Conservacion: "+ estadoDeConservacion+"\nId del descubrimiento: "+id;
    }
    
    @Override
    public boolean equals(Object obj){
        if(this == obj){
            return true;
        }
        if(obj == null || !(obj instanceof Descubrimiento)){
            return false;
        }
        Descubrimiento otro = (Descubrimiento)obj;
        return sitioDeDescubrimiento.equals(otro.getSitioDeDescubrimiento())&& fechaDeDescubrimiento.equals(otro.getFechaDeDescubrimiento()) ;
    }
    
    @Override
    public int hashCode(){
        return java.util.Objects.hash(sitioDeDescubrimiento, fechaDeDescubrimiento);
    }
    

}
