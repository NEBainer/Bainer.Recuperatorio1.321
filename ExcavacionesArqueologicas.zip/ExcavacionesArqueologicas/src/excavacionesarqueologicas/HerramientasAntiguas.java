package excavacionesarqueologicas;

import java.time.LocalDate;


public class HerramientasAntiguas extends Descubrimiento implements Analizable{
    private String material;
    private String usoProbable;

    public HerramientasAntiguas(String sitioDeDescubrimiento, LocalDate fechaDeDescubrimiento, int estadoDeConservacion, String material, String usoProbable) {
        super(sitioDeDescubrimiento, fechaDeDescubrimiento, estadoDeConservacion);
        this.material = material;
        this.usoProbable = usoProbable;
    }

    public String getMaterial() {
        return material;
    }

    public String getUsoProbable() {
        return usoProbable;
    }
    
    @Override
    public void analizar(){
        System.out.println("La herramienta antigua hecha de material " + material + " fue restaurada siendo limpiada cuidadosamente\n");
    }
    
    @Override
    public String toString(){
        return super.toString() + "Material: "+ material + "\nUso probable: " + usoProbable+"\n";
    }
    
    
 
}
