package excavacionesarqueologicas;

import java.util.ArrayList;
import java.util.List;


public class AdministradorDeDescubrimientos {
    
    private List<Descubrimiento> descubrimientos = new ArrayList<>();
    
    public void registrarDescubrimiento(Descubrimiento descubrimientoARegistrar){
        if(descubrimientos.contains(descubrimientoARegistrar)){
            throw new DescubrimientoRepetidoExcepcion("No se pudo registrar el descubrimiento por que ya existe uno en el mismo lugar y misma fecha\n");
        }
        descubrimientos.add(descubrimientoARegistrar);
    }
    
    public void listarDescubrimientos(){
        for(Descubrimiento d: descubrimientos){
            System.out.println(d);
        }
    }
    
    public void ejecutarAnalisis(){
        for(Descubrimiento d: descubrimientos){
            if(d instanceof Analizable){
                ((Analizable) d).analizar();
            } else {
            System.out.println("No se pudo analizar el descubrimiento por que no es analizable" + d.getClass()+ "\n");
                }
        }
        
    }
    
    public void realizarRestauracion(){
        for(Descubrimiento d: descubrimientos){
            if(d instanceof Restaurable){
                ((Restaurable) d).restaurar();
            } else {
            System.out.println("No se pudo restaurar el descubrimiento por que no es restaurable\n"+ d.getClass()+ "\n");
                }
        }
        
    }
    
    public List<ConstruccionRuinosa> filtrarPorEpoca(EpocaHistorica epoca){
        List <ConstruccionRuinosa> listaFiltrada = new ArrayList<>();
        for(Descubrimiento d: descubrimientos){
            if(d instanceof ConstruccionRuinosa){
                if(((ConstruccionRuinosa) d).getEpoca()== epoca){
                   listaFiltrada.add((ConstruccionRuinosa)d);
                }
            }
        }
        return listaFiltrada;
    }
    
    public List<Descubrimiento> mostrarDescubrimientosPorConservacion(int desde, int hasta){
        List<Descubrimiento> listaARetornar = new ArrayList<>();
        for(Descubrimiento d: descubrimientos){
            if(d.getEstadoDeConservacion() >= desde && d.getEstadoDeConservacion()<= hasta){
                listaARetornar.add(d);
            }
        }
        return listaARetornar;
    }

}
