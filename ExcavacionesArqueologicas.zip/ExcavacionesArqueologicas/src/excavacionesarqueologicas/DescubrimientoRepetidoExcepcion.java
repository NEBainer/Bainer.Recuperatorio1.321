package excavacionesarqueologicas;


public class DescubrimientoRepetidoExcepcion extends RuntimeException{

    public DescubrimientoRepetidoExcepcion(String message) {
        super(message);
    }
    
}
