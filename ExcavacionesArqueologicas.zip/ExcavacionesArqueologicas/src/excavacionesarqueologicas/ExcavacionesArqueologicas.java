/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package excavacionesarqueologicas;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ezzeb
 */
public class ExcavacionesArqueologicas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       AdministradorDeDescubrimientos a1 = new AdministradorDeDescubrimientos();
       CargarDescubrimientos(a1);
       
       System.out.println("\n=== LISTA DE DESCUBRIMIENTOS ===");
       a1.listarDescubrimientos();
       
       System.out.println("\n=== INICIAR ANALISIS DE DESCUBRIMIENTOS ===");
       a1.ejecutarAnalisis();
       
       System.out.println("\n=== INICIAR TAREAS DE RESTAURACION EN CONSTRUCCIONES RUINOSAS ===");
       a1.realizarRestauracion();
       
       System.out.println("\n=== FILTRAR HALLAZGOS POR EPOCA HISTORICA ===");
       List<ConstruccionRuinosa> construccionesFiltradas = new ArrayList<ConstruccionRuinosa>(a1.filtrarPorEpoca(EpocaHistorica.COLONIAL));
       System.out.println("\n=== Construcciones ruinosas de la epoca Colonial ===");
       for(ConstruccionRuinosa c: construccionesFiltradas){
           System.out.println(c);
       }
       
       System.out.println("\n=== MOSTRAR DESCUBRIMIENTOS POR ESTADO DE CONSERVACION ===");
       List<Descubrimiento> listaPorConservacion = new ArrayList<Descubrimiento>(a1.mostrarDescubrimientosPorConservacion(7, 10));
       if(listaPorConservacion.isEmpty()){
            System.out.println("No se encontraron descubrimientos con el estado de conservacion buscado");
       }else System.out.println("Descubrimientos con el estado de conservacion buscado: ");
        for(Descubrimiento d: listaPorConservacion){
            System.out.println(d);
        }
        
       
    }
    
    public static void CargarDescubrimientos(AdministradorDeDescubrimientos administrador){
        try{
            administrador.registrarDescubrimiento(new ConstruccionRuinosa("La quiaca", LocalDate.of(1985, 6, 12),7,TipoDeEdificacion.TEMPLO, EpocaHistorica.PRECOLOMBINA));
            administrador.registrarDescubrimiento(new ConstruccionRuinosa("Cusco", LocalDate.of(1999, 11, 3),5,TipoDeEdificacion.VIVIENDA, EpocaHistorica.COLONIAL));
            administrador.registrarDescubrimiento(new ConstruccionRuinosa("Ruinas de Quilmes", LocalDate.of(2020, 3, 18),7,TipoDeEdificacion.VIVIENDA, EpocaHistorica.COLONIAL));
        
            administrador.registrarDescubrimiento(new RestoFosil("Cueva del Milodon", LocalDate.of(2001, 4, 21),8,"Milodon", true));
            administrador.registrarDescubrimiento(new RestoFosil("Valle de la Luna", LocalDate.of(2015, 3, 20),7,"Dinosaurio Sauropodo", true));
            administrador.registrarDescubrimiento(new RestoFosil("Pampa del Indio", LocalDate.of(1990, 1, 5),4,"Glyptodon", false));
        
            administrador.registrarDescubrimiento(new HerramientasAntiguas("Quebrada del Toro", LocalDate.of(1980, 7, 19),3,"Piedra", "Corte"));
            administrador.registrarDescubrimiento(new HerramientasAntiguas("Caverna del Tigre", LocalDate.of(1990, 6, 20),3,"Bronce", "Ceremonial"));
            administrador.registrarDescubrimiento(new HerramientasAntiguas("Isla Martin Garcia", LocalDate.of(1996, 3, 29),10,"Hueso", "Tallado"));
        
            //Para comprobar la excepcion
            administrador.registrarDescubrimiento(new HerramientasAntiguas("Quebrada del Toro", LocalDate.of(1980, 7, 19),3,"Cobre", "Corte"));
        }
        
        catch(DescubrimientoRepetidoExcepcion e){
            System.out.println("Error: " +  e);
        }
        
        
    }
    
}
