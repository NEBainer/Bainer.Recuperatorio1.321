package excavacionesarqueologicas;

import java.time.LocalDate;


public class RestoFosil extends Descubrimiento implements Analizable{
    private String nombreDeEspecie;
    private boolean esqueletoCompleto;

    public RestoFosil( String sitioDeDescubrimiento, LocalDate fechaDeDescubrimiento, int estadoDeConservacion, String nombreDeEspecie, boolean esqueletoCompleto) {
        super(sitioDeDescubrimiento, fechaDeDescubrimiento, estadoDeConservacion);
        this.nombreDeEspecie = nombreDeEspecie;
        this.esqueletoCompleto = esqueletoCompleto;
    }

    public String getNombreDeEspecie() {
        return nombreDeEspecie;
    }

    public boolean isEsqueletoCompleto() {
        return esqueletoCompleto;
    }
    
    private String verificarEsqueleto(){
        if(esqueletoCompleto == true){
            return "Si";
        }
        return "No";
    }
    
    @Override
    public void analizar(){
        System.out.println("El resto fosil de la especie " + nombreDeEspecie + " fue restaurado cuidadosamente\n");
    }
    
    @Override
    public String toString(){
        return super.toString()+ "Nombre de especie:" + nombreDeEspecie + "\nEl esqueleto esta completo?: " + verificarEsqueleto()+"\n";
    }

}
