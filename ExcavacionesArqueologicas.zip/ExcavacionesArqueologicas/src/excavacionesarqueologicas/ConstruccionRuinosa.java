package excavacionesarqueologicas;

import java.time.LocalDate;


public class ConstruccionRuinosa extends Descubrimiento implements Restaurable{
    private TipoDeEdificacion tipoDeEdificio;
    private EpocaHistorica epoca;

    public ConstruccionRuinosa(String sitioDeDescubrimiento, LocalDate fechaDeDescubrimiento, int estadoDeConservacion, TipoDeEdificacion tipoDeEdificio, EpocaHistorica epoca) {
        super(sitioDeDescubrimiento, fechaDeDescubrimiento, estadoDeConservacion);
        this.tipoDeEdificio = tipoDeEdificio;
        this.epoca = epoca;
    }

    public TipoDeEdificacion getTipoDeEdificio() {
        return tipoDeEdificio;
    }

    public EpocaHistorica getEpoca() {
        return epoca;
    }
    
    @Override
    public String toString(){
        return super.toString() + "Tipo de edificio: "+ tipoDeEdificio + "\nEpoca Historica: " + epoca +"\n";
    }
    
    @Override
    public void restaurar(){
        System.out.println("Se restaura la construcion ruiona de la epoca " + epoca +"\n");
    }
    
}
